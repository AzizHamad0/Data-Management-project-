#Teamcode Part5
#Version 1.0

import string
from typing import List
def book_category_dictionary(file_name: str) -> dict:
    """
    The function returns a dictionary from a given file_name. The keys of the dictionary are the categories and the value of the dicitionary are listed as in the specific category such as Fiction, Bibliography, Fantasy. 
    
    >>> book_category_dictionary("google_books_dataset.csv")
    {'Fiction': [{'title': "Antiques Roadkill: A Trash 'n' Treasures Mystery", 'author': 'Barbara Allan', 'rating': '3.3', 'publisher': 'Kensington Publishing Corp.', 'pages': '288', 'language': 'English\n'}, {'title': 'The Painted Man (The Demon Cycle. Book 1)', 'author': 'Peter V. Brett', 'rating': '4.5', 'publisher': 'HarperCollins UK', 'pages': '544', 'language': 'English\n'},...]}
    """    
    infile = open(file_name, 'r')
    csv = []
    for i in infile.readlines():
        csv.append(i.strip())
    csv = list(set(csv))
    book_dictionary = {}
    for line in csv:
        categories = line.strip("\n")
        categories = line.split(',')         
        if categories[5] not in book_dictionary.keys():
            book_dictionary.update({categories[5]:[{"title": categories[0], "author": categories[1],"rating": categories[2], "publisher": categories[3], "pages":categories[4],"language": categories[6]}]})
        
        elif categories[5] in book_dictionary.keys():
            a = book_dictionary.get(categories[5]) 
            b = a + [{"title": categories[0], "author": categories[1],"rating": categories[2], "publisher": categories[3], "pages":categories[4],"language": categories[6]}]
            book_dictionary.update({categories[5]:b})
        
        if categories[5] == 'category':
            book_dictionary.pop('category')
            
        lst = []
        result = {}   
        for key, val in book_dictionary.items():
            if val not in lst:
                lst.append(val)
                result[key] = val
                
    infile.close()
            
    return result
print(book_category_dictionary('google_books_dataset.csv'))
