#Teamcode Part4
#Version 1.0

from T109_P5_load_data import book_category_dictionary
from T109_P2_add_remove_search_dataset import get_books_by_category, get_books_by_publisher, get_all_categories_for_book_title, remove_book, add_book, get_books_by_rate, get_books_by_title, get_books_by_author
from T109_P3_sorting_fun import sort_books_title, sort_books_publisher, sort_books_author, sort_books_ascending_rate


def sort_tit(get:dict)-> None:
    '''
    When called,The function creates a list, The function returns a list with the book data stored as a dictionary book where the books are 
    sorted alphabetically by title.
    '''
    sorting_tit = sort_books_title(get)
    print(sorting_tit)
    
def sort_pub(get:dict)-> None:
    '''
    When called, the function creates a list, and returns a list with the book data stored as a dictionary book where the books are 
    sorted alphabetically by publisher.
    '''
    sorting_pub = sort_books_publisher(get)
    print(sorting_pub)
    
def sort_auth(get:dict)-> None:
    '''
    When called, function takes a dictionary of books, and puts them in a list. Then the function uses a bubble sorting algorithm to sort the books based on their author 
    in alphabetical order. function returns a list with the book data stored as a dictionary book where the books are
    '''
    sorting_auth = sort_books_author(get)
    print(sorting_auth)
    
def sort_rate(get:dict)-> None:
    '''
    When called, returns a list with the book data stored as a dictionary book where the books are
    sorted by their rate in ascending order.The function creates a list with the book data. Each list element is a dictionary where all book
    data is stored. the function uses a bubble sorting algorithm to sort the books by the rate in ascending order. Books with the ‘N/A’ rate should appear
    first. Books with the same rate must be sorted based on their title.
    '''
    sorting_rate = sort_books_ascending_rate(get)
    print(sorting_rate)


def adding_books(get:dict)-> None:
    '''
    When called, the function adds a book of a specific discription givin by the user 
    '''
    title = input('please enter the title of the book: ')
    author = input('please enter the author of the book: ')
    rating = input('please enter the rating of the book: ')
    publisher = input('please enter the publisher of the book: ')
    pages = input('please enter the pages of the book: ')
    language = input('please enter the language of the book: ')
    category = input('please enter the category of the book: ')
    my_tuple = (title, author, language, publisher, category, rating, pages)    
    add = add_book(get,my_tuple)
    print(add)
    
def removing_books(get:dict)-> None:
    '''
    When called, this function takes the title and category of a book and removes it from a given dictionary. If the book is not in the dictionary, the function returns "There was an error removing the book. Book not found".
    '''
    removing = input('please enter the title you want: ')
    categ = input('please enter the category you want: ')
    remove = remove_book(removing,categ,get)
    print(remove)
    
def get_book_title(get:dict)-> None:
    '''
    When called, this function takes two parameters. The dictionary and the book title. The function then reads through the dictionary to find the the books title and returns "True, The book has been found" or "False, the book has NOT been found"
    '''
    title = input('please enter the title you want: ')
    get_tit = get_books_by_title(title,get)
    print(get_tit)
    
def get_book_auth(get:dict)-> None:
    '''
    When called, the function takes a dictionary of books defined by their categroies, then it returns the number of books written by the author (the same book
    in a different category counts as a single book). Additionally, the function prints all the titles by the given author and the books rating.
    '''
    auth = input('please enter the author you want: ')
    get_auth = get_books_by_author(auth,get)
    print(get_auth)
    
def get_book_rate(get:dict)-> None:
    '''
    When called, the function takes a dictionary of books defined by their categroies, then it returns the number of books between the given rate and the given rate +1 (the same 
    book in a different category counts as a single book)
    '''
    rate = float(input('please enter the rate you want: '))
    get_rate = get_books_by_rate(rate, get)
    print(get_rate)
    
def all_categories_for_book_title(get:dict)-> None:
    '''
    When called, the function returns the number of categories associated with the given title.
    '''
    title = input('please enter the book title: ')
    all_cat = get_all_categories_for_book_title(get, title)
    print(all_cat)
    
def get_book_cat(get:dict)-> None:
    '''
    When called, the function returns the number of books by the given category. Additionally, the function prints the books information for that category.The function has two input parameters, (1) the dictionary where the data is stored and (2) the category.
    '''
    cat = input('please enter the category you want: ')
    get_cat = get_books_by_category(get, cat)
    print(get_cat)
    
def get_book_pub(get:dict)-> None:
    '''
    When called, the function returns the number of books published by the given publisher’s. Additionally, the function prints the books information for that publisher.The function has two input parameters, (1) the dictionary where the data is stored and (2) the publisher’s name.
    '''
    pub = input('please enter the publisher you want: ')
    get_pub = get_books_by_publisher(get,pub)
    print(get_pub)

if __name__ == '__main__':  
    loaddata = 'L'
    add = 'A'
    remove = 'R'
    get_books = 'G'
    Publisher = 'P'
    Category = 'C'
    title = 'T'
    rate = 'R'
    author = 'A'
    gct = 'GCT'
    sort = 'S'
    quit = 'Q'
    lst = [loaddata, add, remove, get_books, Publisher, Category,title,rate,author,gct,sort,quit]
    while True:
        string = input('The available commands are:\n1- L)oad data\n2- A)dd book\n3- R)emove book\n4- G)et books\n    T)itle R)ate A)uthor P)ublisher C)ategory\n5- GCT) Get all Categories for book Title\n6- S)ort books\n    T)itle R)ate P)ublisher A)uthor\n7- (Q to quit):\n\nPlease type your command: ')
        isupper = string.upper()
    
        if isupper == loaddata:
            file = input('Please enter the name of the file you want to load: ')
            get = book_category_dictionary(file)
            first = input('The available commands are:\n1- L)oad data\n2- A)dd book\n3- R)emove book\n4- G)et books\n    T)itle R)ate A)uthor P)ublisher C)ategory\n5- GCT) Get all Categories for book Title\n6- S)ort books\n    T)itle R)ate P)ublisher A)uthor\n7- (Q to quit):\n\nPlease type your command: ')
            second = first.upper()
            if second == add: #add books
                adding_books(get)
            if second == remove: #remove books
                removing_books(get)            
            if second == get_books: #get books
                option = input('How do you want to get books?\n T)itle R)ate A)uthor P)ublisher C)ategory\n\nPlease type your command: ')
                option1= option.upper()
                if option1 == Publisher:
                    get_book_pub(get)
                elif option1 == Category:
                    get_book_cat(get)
                elif option1 == title:
                    get_book_title(get)
                elif option1 == author:
                    get_book_auth(get)
                elif option1 == rate:
                    get_book_rate(get)
            if second == sort: #sorting out books
                option = input('How do you want to sort books?\n T)itle R)ate P)ublisher A)uthor\n\nPlease type your command: ')
                option1= option.upper()
                if option1 == Publisher:
                    sort_pub(get)
                elif option1 == title:
                    sort_tit(get)
                elif option1 == author:
                    sort_auth(get)
                elif option1 == rate:
                    sort_rate(get)                
            elif second == gct: #get all categories for a title 
                all_categories_for_book_title(get)
            elif second == quit:#quits program when user enters q after loading data
                print('the program has been terminated')
                break
            elif second not in lst: #when user enters a letter that is not from the list after loading data
                print('Invalid command. Please try again.')            
        elif isupper == quit: #quits program when user enters q before loading data
            print('the program has been terminated')
            break    
        elif isupper in lst: 
            print('file not loaded')    
        else: #when user enters a letter that is not from the list before loading data
            print('Invalid command. Please try again.')
