#Teamcode Part2

#Version 1.0

import string
from typing import List
from T109_P5_load_data import book_category_dictionary





def add_book(category_dict: dict, book: tuple) -> dict:
    """
    Adds a book of a specific category into the dictionary of categories.
    """
    book_has_been_added = False
    add_book = False
    update_category = False    
    for category in category_dict:
        if category not in category_dict:
            category_dict[category] = []        
        if book[4] == category:
            book_has_been_added = True
            new_book = {'title':book[0],'author':book[1],'rating':book[5],'publisher':book[3],'pages':book[6], 'language':book[2]}
            add_book = True
        else:
            book_has_been_added = True
            new_book = {'title':book[0],'author':book[1],'rating':book[5],'publisher':book[3],'pages':book[6], 'language':book[2]}
            update_category = True
    
    if update_category == True:
        category_dict.update({book[4]:new_book})
    if add_book == True:
        category_dict[category].append(new_book)       
    if book_has_been_added == True:
        print("The book has been added correctly.")
    else:
        print("There was an error adding the book.")        
        
    return category_dict    




def remove_book(title,category,dictionary):
    """
    This function takes the title and category of a book and removes it from a given dictionary. If the book is not in the dictionary, the function returns "There was an error removing the book. Book not found".
    
    Examples:
    INPUT:
    >>> print (remove_book("Antiques Roadkill: A Trash 'n' Treasures Mystery", "Fiction", book_author_dictionary(file_name)))
    
    OUTPUT:
    >>> {'Barbara Allan': [{'title': 'Antiques Con', 'rating': '4.8', 'publisher': 'Kensington Books', 'pages': '288', 'category': 'Fiction', 'language': 'English\n'},
    # The first book in the dictionary was removed
    >>> Antiques Roadkill: A Trash 'n' Treasures Mystery Fiction
    >>> test Antiques Roadkill: A Trash 'n' Treasures Mystery
    >>> The book has been removed correctly
    
    """
    
    if category in dictionary:
        books = dictionary.get(category)
        for book in books:
            if book ["title"] == title:
                books.remove(book)
                print("The book has been removed correctly")
                break        
        else:
            print("There was an error removing the book. Book not found.")
    else:
        print("There was an error removing the book. Book not found.")            
    return dictionary 


def get_books_by_category(dictionary: dict, category: str) -> int:
    books_in_category = dictionary[category]
    count = 0
    for book in books_in_category:
        count += 1
        
    print('The category', category, 'has', count, 'books. This is the list of books:')
    book_no = 0
    for book in books_in_category:
        book_no += 1
        print('Book ', book_no, ': ', book['title'], ' by ', book['author'])
        
    return count



def get_books_by_rate(rate: int, dictionary: dict) ->int:
    '''
    the function takes a dictionary of books defined by their categroies, then it returns the number of books between the given rate and the given rate +1 (the same 
    book in a different category counts as a single book)
    >>>get_books_by_rate(3, book_category_dictionary("google_books_dataset.csv"))
    There are 8 books whose rate is between 3 and 4. This is the list of books:
    Book 1: Antiques Roadkill: A Trash 'n' Treasures Mystery by Barbara Allan
    Book 2: Bring Me Back by B A Paris
    Book 3: Mrs. Pollifax Unveiled by Dorothy Gilman
    Book 4: How to Understand Business Finance: Edition 2 by Bob Cinnamon
    Book 5: The Secrets of Saving and Investing with Alvin Hall: Simple Strategies to Make Your Money Go Further by Alvin Hall
    Book 6: Freakonomics Rev Ed: A Rogue Economist Explores the Hidden Side of Everything by Steven D. Levitt
    Book 7: The Infinite Game by Simon Sinek
    Book 8: Selling 101: What Every Successful Sales Professional Needs to Know by Zig Ziglar
    8
    '''
    if rate < 0:
        print("The rate must be a positive integer")
        return []
    rated_books = []
    for category in dictionary:
        for book in dictionary[category]:
            if 'N/A' not in book['rating'] and rate <= float(book['rating']) < rate + 1 and book not in rated_books:
                rated_books.append(book)

    print(f'There are {len(rated_books)} books whose rate is between {rate} and {rate+1}. This is the list of books:')
    for i, book in enumerate(rated_books):
        print(f'Book {i+1}: {book["title"]} by {book["author"]}')
    return len(rated_books)





def get_books_by_title(title,dictionary):
    """
    This function takes two parameters. The dictionary and the book title. The function then reads through the dictionary to find the the books title and returns "True, The book has been found" or "False, the book has NOT been found"
    
    Examples:
    INPUT:
    >>> print(get_books_by_title("Little Girl Lost: A Lucy Black Thriller",(book_author_dictionary(file_name))))
    
    OUTPUT:
    >>> The book has been found
    >>> True
    
    INPUT:
    >>> print(get_books_by_title("chicken egg",(book_author_dictionary(file_name))))
    
    OUTPUT:
    >>> The book has NOT been found
    >>> False
    """

    for row in dictionary.values():
        for titles in row:
            if(titles['title']== title):
                print("The book has been found")
                return True          
    
    print("The book has NOT been found")
    return False    



def get_books_by_author(name: str, dictionary: dict) -> int:
    '''
    the function takes a dictionary of books defined by their categroies, then it returns the number of books written by the author (the same book
    in a different category counts as a single book). Additionally, the function prints all the titles by the given author and the books rating.
    >>>get_books_by_author("Andrzej Sapkowski", book_category_dictionary("google_books_dataset.csv"))
    The author  Andrzej Sapkowski has published the following books:
    Book 1 :  Sword of Destiny: Witcher 2: Tales of the Witcher ,rate: 4.8
    Book 2 :  The Tower of the Swallow: Witcher 6 ,rate: 4.6
    Book 3 :  The Malady and Other Stories: An Andrzej Sapkowski Sampler ,rate: 4.8
    3
    '''
    authors_books = []
    lowercase_name = name.lower()
    for category in dictionary:
        for book in dictionary[category]:
            if book['author'].lower() == lowercase_name and book not in authors_books:
                authors_books.append(book)
    if not len(authors_books):
        print('The author ' ,name, ' has published no books yet.')
        return 0
    
    print('The author ',name, 'has published the following books:')
    for i, book in enumerate(authors_books):
        print('Book' ,i+1, ': ',book["title"],',rate:' ,book["rating"])
    return len(authors_books)



def get_books_by_publisher(dictionary,publisher):
    """The function returns the number of books published by the given publisher’s. Additionally, the function prints the books information for that publisher.The function has two input parameters, (1) the dictionary where the data is stored and (2) the publisher’s name.
    >>> get_books_by_publisher((book_category_dictionary("google_books_dataset.csv")),'Tor Books'))
    The publisher  Tor Books has published the following books:
    Book 1 :  Edgedancer: From the Stormlight Archive ,rate: 4.8
    Book 2 :  Mistborn Trilogy: The Final Empire. The Well of Ascension. The Hero of Ages ,rate: 4.7
    2    
    """
    l = []
    lowercase_publisher = publisher.lower()
    for category in dictionary:
        for book in dictionary[category]:
            if book['publisher'].lower() == lowercase_publisher and book not in l:
                l.append(book)
    if not len(l):
        print('The Publisher ' ,publisher, ' has no books published.')
        return 0
    
    print('The publisher ',publisher, 'has published the following books:')
    for i, book in enumerate(l):
        print('Book' ,i+1, ': ',book["title"],',rate:' ,book["rating"])
    return len(l)   





def get_all_categories_for_book_title(dictionary, title):
    """The function returns the number of categories associated with the given title.
    >>> get_all_categories_for_book_title((book_category_dictionary("google_books_dataset.csv")),'After Anna'))
    The book title After Anna  has the following categories:
    Category 1 : "Fiction"
    Category 2 : "Thrillers"
    Category 3 : "Mystery"
    Category 4 : "Adventure"
    4
    """
    count_1 = 0
    all_categories = []
    category = []
    for i in dictionary:
            all_categories += [i]
    
    for i in all_categories:
        val= dictionary.get(i)
        for j in val:
            if j.get('title') == title:
                category += [i]
                count_1 += 1
                        
    print("The book title",title," has the following categories:")
    count_2 = 0
    for i in category:
        count_2 += 1 
        print("Category",count_2,":",'"'+i+'"')
            
    return count_1 


