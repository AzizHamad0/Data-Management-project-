#Teamcode Part3
#Version 1.0


from T109_P5_load_data import book_category_dictionary
from typing import List




def sort_books_title(dic:dict)->List[dict]:
    """
    The function creates a list, The function returns a list with the book data stored as a dictionary book where the books are 
    sorted alphabetically by title.
    """
    books_title = []
    for key in dic.keys():
        
        for book in dic[key]:
            book.update({'category':[key]})
    for add_book in dic.values():
        for each_book in add_book:
            books_title.append(each_book)
    for check_dupe in books_title:
        for dupe in books_title:
            if check_dupe != dupe:
                if check_dupe['title'] == dupe['title']: 
                    original_value = check_dupe.get('category')
                    dupe_category = dupe.get('category')
                    books_title.remove(dupe)
                    check_dupe.update({'category':original_value + dupe_category})
                    
    n = len(books_title)
    for i in range(n):
        for j in range(n-i-1):
            if books_title[j]['title'.lower()].strip("\'") > books_title[j+1]['title'.lower()].strip("\'"):
                books_title[j], books_title[j+1] = books_title[j+1], books_title[j]    
    return books_title

def sort_books_publisher(dictionary:dict) -> list:
    """
    The function creates a list, and returns a list with the book data stored as a dictionary book where the books are 
    sorted alphabetically by publisher.
    >>>sort_books_publisher(book_category_dictionary('google_books_dataset.csv'))
    [{'title': 'The Essentials of Finance and Accounting for Nonfinancial Managers', 'author': 'Edward Fields', 'rating': 'N/A', 'publisher': 'AMACOM', 'pages': '320', 'language': 'English\n', 'category': ['Economics', 'Economics', 'Economics', 'Economics', 'Economics', 'Business', 'Business', 'Business', 'Management']}]
    """
    
    books = []
    
    for categorys in dictionary.keys():
        for book in dictionary[categorys]:
            book.update({'category':[categorys]})
            
    for bookz in dictionary.values():
        for each_book in bookz:
            books.append(each_book)
            
    for multiple in books:
        for duplicates in books:
            if multiple != duplicates:
                if multiple['publisher'] == duplicates['publisher']: 
                    original_value = multiple.get('category')
                    duplicates_category = duplicates.get('category')
                    books.remove(duplicates)
                    multiple.update({'category':original_value + duplicates_category})
                    
    for i in range(len(books)):
        for x in range(len(books)-i-1):
            if books[x]['publisher'.lower()].strip("\'") > books[x+1]['publisher'.lower()].strip("\'"):
                books[x], books[x+1] = books[x+1], books[x] 
    return books
    

def sort_books_author(dic:dict) -> list:
    '''
    function takes a dictionary of books, and puts them in a list. Then the function uses a bubble sorting algorithm to sort the books based on their author 
    in alphabetical order. function returns a list with the book data stored as a dictionary book where the books are
    sorted alphabetically by author name
    >>>print(sort_books_author(book_category_dictionary("google_books_dataset.csv")))
    [{'title': 'Twas The Nightshift Before Christmas: Festive hospital diaries from the author of million-copy hit This is Going to Hurt', 'author': 'Adam Kay', 'rating': '4.7', 'publisher': 'Pan Macmillan', 'pages': '112', 'language': 'English\n', 'category': ['Humor']}, {'title': 'And Then There Were None', 'author': 'Agatha Christie', 'rating': '4.6', 'publisher': 'HarperCollins UK', 'pages': '224', 'language': 'English\n', 'category': ['Fiction', 'Detective', 'Thrillers', 'Mystery']},
    '''
    list_authors = []
    for category in dic.keys():
        books = dic[category] 
        print("List:", books)
        for item in books: 
            in_list = False
            for i in range(len(list_authors)):
                if list_authors[i]['title'] == item['title']:
                    list_authors[i]['category'] += [category]
                    in_list = True
            if in_list == False:
                item['category'] = [category]           
                list_authors += [item]
    swap = True
    while swap:
        swap = False
        for i in range(len(list_authors) -1):
            if list_authors[i]['author'] > list_authors[i+1]['author']:
                x = list_authors[i]
                list_authors[i] = list_authors[i+1]
                list_authors[i+1] = x
                swap = True
            elif list_authors[i]['author'] == list_authors[i+1]['author']: 
                if list_authors[i]['title'] > list_authors[i+1]['title']:
                    x = list_authors[i]
                    list_authors[i] = list_authors[i+1]
                    list_authors[i+1] = x
                    swap = True                                
    return list_authors    



def sort_books_ascending_rate(dic:dict) -> list:
    '''returns a list with the book data stored as a dictionary book where the books are
sorted by their rate in ascending order.The function creates a list with the book data. Each list element is a dictionary where all book
data is stored. the function uses a bubble sorting algorithm to sort the books by the rate in ascending order. Books with the ‘N/A’ rate should appear
first. Books with the same rate must be sorted based on their title.
    
    '''
    
    title_list = []
    book_list = []
    
    for category in dic:
        for book in dic[category]:
            if book['title'] not in title_list:
                title_list.append(book['title'])
                
    for title in title_list:
        category_list = []
        for category in dic:
            for book in dic[category]:
                if title == book['title']:
                    category_list += [category]
                    author = book ['author']
                    rating = book ['rating']
                    publisher = book ['publisher']
                    pages = book ['pages']
                    language = book ['language']
                    
        book_list.append({'title':title, 'author':author, 'language':language, 'rating':rating, 'publisher':publisher, 'category':category_list, 'pages':pages})
     
                    
        
    n = len(book_list)
    for i in range(n):
            for j in range(0,n-i-1):
                b1 = book_list[j]
                b2 = book_list[j+1]
                if b1['rating'] == 'N/A' and b2['rating'] == 'N/A':
                    if b1['title'] > b2['title']:
                        book_list[j] = b2
                        book_list[j+1] = b1            
                elif b1['rating'] == 'N/A' and b2['rating'] != 'N/A':
                    book_list[j] = b1
                    book_list[j+1] = b2
                elif b2['rating'] == 'N/A' and b1['rating'] != 'N/A':
                    book_list[j] = b2
                    book_list[j+1] = b1
                elif b1['rating'] != 'N/A' and b2['rating'] != 'N/A':
                    r1 = float(b1['rating'])
                    r2 = float(b2['rating'])
                    if r1 > r2:
                        book_list[j] = b2
                        book_list[j+1] = b1
                    elif r1 == r2:
                        if b1['title'] > b2['title']:
                            book_list[j] = b2
                            book_list[j+1] = b1                              
                                
    for count, book in enumerate(book_list, start=1):
        print(f'book{count} ={book}') 
        
    return book_list

